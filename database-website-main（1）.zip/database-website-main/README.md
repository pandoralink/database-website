# 技术栈

1. vue3
2. typescript

# 环境介绍

vue3 + volar + element-plus + axios + vue-router + vs code + mock.js

# 内容介绍

用于展示数据库的一些内容

# 待补充

1. 可以加上面包屑导航，到第三级路由的时候就没有地方返回了
2. 登录退出部分

# 总结

typescript + `<script setup lang="ts">` 用起来就是爽啊！家人们！
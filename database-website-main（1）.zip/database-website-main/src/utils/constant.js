const path = {
  LOGIN: "/api/user/login",
  LOGOUT: "/api/user/logout"
}

export const EmpolyImg = "https://img0.baidu.com/it/u=1479178160,1916382043&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=505";

export default path;
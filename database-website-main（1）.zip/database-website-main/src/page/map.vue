<template>
  <empty desc="暂未开发"></empty>
</template>

<script setup lang="ts">
import empty from "./empty.vue";
</script>

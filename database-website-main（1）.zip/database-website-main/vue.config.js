module.exports = {
  productionSourceMap: false
}